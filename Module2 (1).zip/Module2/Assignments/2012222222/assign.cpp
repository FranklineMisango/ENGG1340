// We intend to make this file can be compiled, but contains logical error.
#include<iostream>
using namespace std;
int main(){
   int a,b,c; 
   cin >> a;
   cin >> b;
   cin >> c;
   cout << a*b*c+1000 << endl;
}
